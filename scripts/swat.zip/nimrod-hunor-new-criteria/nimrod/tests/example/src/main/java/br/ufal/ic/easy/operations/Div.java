package br.ufal.ic.easy.operations;

public class Div implements Operation {

    public int execute(int a, int b) {
        return a / b;
    }
}