package br.ufal.ic.easy.operations;

public interface Operation {

    public int execute(int a, int b);

}