package br.ufal.ic.easy.operations;

public class Sub implements Operation {

    public int execute(int a, int b) {
        return a - b;
    }
}