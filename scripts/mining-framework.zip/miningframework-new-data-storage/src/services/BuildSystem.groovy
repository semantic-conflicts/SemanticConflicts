package services

public enum BuildSystem {
    Maven,
    Gradle,
    None
}
