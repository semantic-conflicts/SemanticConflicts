package main.interfaces

import main.project.*

public interface OutputProcessor {

    public void processOutput()

}