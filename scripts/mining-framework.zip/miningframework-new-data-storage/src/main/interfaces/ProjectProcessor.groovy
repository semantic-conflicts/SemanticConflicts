package main.interfaces

import main.project.*

public interface ProjectProcessor {

    public ArrayList<Project> processProjects(ArrayList<Project> projects)

}