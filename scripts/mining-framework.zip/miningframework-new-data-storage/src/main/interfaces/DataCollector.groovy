package main.interfaces

import main.project.*

public interface DataCollector {

    public void collectData(Project project, MergeCommit mergeCommit)

}