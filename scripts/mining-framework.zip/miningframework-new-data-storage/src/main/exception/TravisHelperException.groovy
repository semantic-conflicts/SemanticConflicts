package main.exception

public class TravisHelperException extends Exception {
    public TravisHelperException(String message) {
        super(message)
    }
}