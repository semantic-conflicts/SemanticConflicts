package main.exception

public class GithubHelperException extends Exception {
    public GithubHelperException(String message) {
        super(message)
    }
}