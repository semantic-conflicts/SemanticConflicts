class Test {
	void addSameLine() {
		int x = 0;
	}

	void removeSameLine() {
		int x = 0;
		int y = 0;
	}

	void modifySameLine() {
		int x = 0;
	}

}
