class Test {

    public void deletionSingleAndAddition() {
        int x = 0;
        int y = 1;
        int z = 0;
    }

    public void deletionBothAndAddition() {
        int x = 0;
        int y = 1;
        int z = 0;
    }

}
