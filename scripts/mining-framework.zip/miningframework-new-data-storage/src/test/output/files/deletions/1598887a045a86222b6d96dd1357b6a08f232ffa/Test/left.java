class Test {

    public void deletionSingleAndAddition() {
        int x = 0;
        int z = 0;
        int d = 1;
    }

    public void deletionBothAndAddition() {
        int x = 0;
        int z = 0;
        int d = 1;
    }

    public void deletionBothAndAdditionBoth() {
        int x = 0;
        int r = 1;
        int z = 0;
        int w = 1;
    }

    public void deletionAndAdditionBoth() {
        int x = 0;
        int r = 1;
        int z = 0;
    }

}
