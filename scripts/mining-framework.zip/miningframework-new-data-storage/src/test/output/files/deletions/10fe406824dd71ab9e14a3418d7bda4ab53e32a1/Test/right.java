class Test {

    public void deletionSingleAndAddition() {
        int x = 0;
        int y = 1;
        int z = 0;
        int d = 1;
    }

    public void deletionBothAndAddition() {
        int x = 0;
        int z = 0;
        int d = 1;
    }

}
