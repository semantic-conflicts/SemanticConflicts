class Test {
	public void mergeConflictOne() {
		int x = 1;
	}

	public void mergeConflictTwo () {
		int y = 1;
	}

	public void noConflict () {
		int x = 0;
		int y = 0;
	}
}
