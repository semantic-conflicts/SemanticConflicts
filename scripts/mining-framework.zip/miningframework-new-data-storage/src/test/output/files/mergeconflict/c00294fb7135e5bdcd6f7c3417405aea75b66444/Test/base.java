class Test {
	public void twoConflictsInOneFile1() {
		int x = 0;
	}

	public void mergeConflictOne() {
		int x = 2;
	}

	public void mergeConflictTwo () {
		int y = 1;
	}

	public void noConflict () {
		int z = 0;
		int x = 0;
		int y = 0;
	}

	public void multipleConflicts () {
		int x = 2;
	}

	public void twoConflictsInOneFile2() {
		int x = 0;
	}
}
