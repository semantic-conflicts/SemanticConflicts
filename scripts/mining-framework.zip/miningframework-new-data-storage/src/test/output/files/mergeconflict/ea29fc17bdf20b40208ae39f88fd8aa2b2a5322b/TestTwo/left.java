class TestTwo {
	public void multipleConflicts() {
		int x = 2;
	}

}
