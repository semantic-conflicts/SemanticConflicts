class Test {
	public void mergeConflictOne() {
		int x = 0;
	}

	public void mergeConflictTwo () {
		int y = 0;
	}

	public void noConflict () {
		int x = 0;
	}
}
