
package test.util

import main.interfaces.OutputProcessor

class EmptyOutputProcessor implements OutputProcessor {
    
    public void processOutput() {
    }

}